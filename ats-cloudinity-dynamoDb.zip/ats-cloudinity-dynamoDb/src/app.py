import json
import boto3
from botocore.exceptions import ClientError
import datetime

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('ats-cloudinity-table') 

def lambda_handler(event, context):
    print("Received event:", json.dumps(event, indent=2))  # Log the event for debugging

    try:
        # Handle different potential event structures
        if 'body' in event:
            request_body = json.loads(event['body'])
        else:
            request_body = event    

       # Validate required fields
        if not request_body.get('ReqId'):
            raise ValueError('Missing required field: reqId')

        if not request_body.get('FullName'):
            raise ValueError('Missing required field: fullName')

        current_date = datetime.datetime.now().strftime("%Y-%m-%d") 

        # Map form fields to DynamoDB attributes with type checks and defaults
        item = {
            'ReqId': int(request_body.get('ReqId')),  
            'FullName': request_body.get('FullName'),
            'BillRate': request_body.get('BillRate'),  
            'BillRate Margin': request_body.get('BillRate Margin'),  
            'Candidate Current Location': request_body.get('Candidate Current Location'),
            'Candidate Pay Rate $$': request_body.get('Candidate Pay Rate $$'), 
            'Contact Number': request_body.get('Contact Number'),
            'Contract Type': request_body.get('Contract Type'),
            'DOB (MM/DD)': request_body.get('DOB (MM/DD)'),  
            'Email Id': request_body.get('Email Id'),
            'Employer Information': request_body.get('Employer Information'),
            'Formatted By': request_body.get('Formatted By'),
            'Immigration Status': request_body.get('Immigration Status'),
            'LinkedIn ID': request_body.get('LinkedIn ID'),
            'Professional References': request_body.get('Professional References'),
            'Recruiter Name': request_body.get('Recruiter Name'),
            'Req Creation Date': request_body.get('Req Creation Date'), 
            'Req Skills': request_body.get('Req Skills'),
            'Req Submission End date': request_body.get('Req Submission End date'), 
            'Req Title': request_body.get('Req Title'),
            'Resume Formatting Needed?': request_body.get('Resume Formatting Needed?'),  
            'ResumeSource (LinkedIn/Corp/BenchSales)': request_body.get('ResumeSource (LinkedIn/Corp/BenchSales)'),
            'Role': request_body.get('Role'),
            'State': request_body.get('State'),
            'Submission Date': request_body.get('Submission Date'), 
            'Submission Status': request_body.get('Submission Status'),
            'Vender Rate $$': request_body.get('Vender Rate $$'), 
            'Vendor ID': request_body.get('Vendor ID'), 
            'Date': current_date
        }

        # Put item into DynamoDB table
        response = table.put_item(Item=item)

        return {
            'statusCode': 200,
            'body': json.dumps({'message': 'Item added successfully'}),
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
        }

    except (ValueError, ClientError) as e:
        return {
            'statusCode': 400 if isinstance(e, ValueError) else 500,
            'body': json.dumps({'message': str(e)}),
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
        }

